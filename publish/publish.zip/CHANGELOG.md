- v1.44
  - Tools split to Infinity Tools mod.
  - Adds mandatory requirement of Server Devcommands mod.
  - Adds new settings "No primary target" and "No secondary target".
  - Changes number precision of blueprints from 6 to 3 (reduces file size).
  - Changes setting "Infinite health" to "Set invulnerability".
  - Fixes issue when trying to copy objects with removed colliders.
  - Fixes issues with latest Comfy Gizmo.
  - Removes settings "All objects" and "Copy state" as obsolete. These are now always enabled.

- v1.43
  - Adds a new setting to disable blueprint data saving.
  - Fixes repair destroying players (not tested).
  - Fixes copied objects or objects from blueprints sometimes disappearing.

- v1.42
  - Adds support for connected ZDO when copying objects.

- v1.41
  - Fixes copying not working for damaged stone or mineral deposits.

- v1.40
  - Adds a new command `hammer_restore` that selects a blueprint and automatically sets hammer at its position and rotation.
  - Adds a new command `hammer_pos` that allows setting the hammer position and rotation.
  - Changes the `hammer_save` command to save hammer position and rotation to the blueprint file.
  - Changes the `hammer_save` command to print hammer position and rotation to the console.
  - Changes the `hammer_save` command to automatically load the saved blueprint.
  - Changes the `hammer_grid` to use X,Z,Y format instead of X,Y,Z.
  - Fixed for the new patch.

- v1.39
  - Fixed for the new patch.

- v1.38
  - Fixes custom data and undo/redo not working on servers.
  - Fixes not working with the latest Comfy Gizmo.
